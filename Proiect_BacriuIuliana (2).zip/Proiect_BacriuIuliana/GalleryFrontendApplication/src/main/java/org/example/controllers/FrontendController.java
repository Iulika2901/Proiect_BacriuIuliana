package org.example.controllers;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.models.ArtistDTO;
import org.example.models.PaintingDTO;
import org.example.models.UserDTO;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestTemplate;
import jakarta.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.util.List;

@Controller
public class FrontendController {

    private final RestTemplate restTemplate = new RestTemplate();
    private final String GATEWAY_URL = "http://localhost:9000/api/Artist";

    @GetMapping("/")
    public String indexPage() {
        return "index";
    }

    @GetMapping("/artists")
    public String artistsPage(Model model) {
        try {
            ArtistDTO[] artists = restTemplate.getForObject(GATEWAY_URL, ArtistDTO[].class);
            model.addAttribute("artistsList", artists);
        } catch (Exception e) {
            model.addAttribute("artistsList", new ArtistDTO[0]);
        }
        return "artists";
    }

    // 1. Export CSV
    @GetMapping("/artists/export/csv")
    public void exportCSV(HttpServletResponse response) throws Exception {
        response.setContentType("text/csv; charset=UTF-8");
        response.setHeader("Content-Disposition", "attachment; filename=\"artisti.csv\"");
        ArtistDTO[] artists = restTemplate.getForObject(GATEWAY_URL, ArtistDTO[].class);
        PrintWriter writer = response.getWriter();
        writer.println("ID,Nume,Nationalitate");
        if (artists != null) {
            for (ArtistDTO a : artists) {
                writer.println(a.getId() + "," + a.getName() + "," + a.getNationality());
            }
        }
    }

    // 2. Export JSON
    @GetMapping("/artists/export/json")
    public void exportJSON(HttpServletResponse response) throws Exception {
        response.setContentType("application/json; charset=UTF-8");
        response.setHeader("Content-Disposition", "attachment; filename=\"artisti.json\"");
        ArtistDTO[] artists = restTemplate.getForObject(GATEWAY_URL, ArtistDTO[].class);

        // Transformăm lista Java într-un text JSON formatat frumos
        ObjectMapper mapper = new ObjectMapper();
        response.getWriter().write(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(artists));
    }

    // 3. Export XML
    @GetMapping("/artists/export/xml")
    public void exportXML(HttpServletResponse response) throws Exception {
        response.setContentType("application/xml; charset=UTF-8");
        response.setHeader("Content-Disposition", "attachment; filename=\"artisti.xml\"");
        ArtistDTO[] artists = restTemplate.getForObject(GATEWAY_URL, ArtistDTO[].class);
        PrintWriter writer = response.getWriter();

        // Construim manual structura XML
        writer.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        writer.println("<artists>");
        if (artists != null) {
            for (ArtistDTO a : artists) {
                writer.println("  <artist>");
                writer.println("    <id>" + a.getId() + "</id>");
                writer.println("    <name>" + a.getName() + "</name>");
                writer.println("    <nationality>" + a.getNationality() + "</nationality>");
                writer.println("  </artist>");
            }
        }
        writer.println("</artists>");
    }

    // 4. Export DOC (Folosim un truc: un tabel HTML salvat cu extensia .doc va fi citit perfect de MS Word)
    @GetMapping("/artists/export/doc")
    public void exportDOC(HttpServletResponse response) throws Exception {
        response.setContentType("application/msword; charset=UTF-8");
        response.setHeader("Content-Disposition", "attachment; filename=\"artisti.doc\"");
        ArtistDTO[] artists = restTemplate.getForObject(GATEWAY_URL, ArtistDTO[].class);
        PrintWriter writer = response.getWriter();

        writer.println("<html><body>");
        writer.println("<h1>Lista Artisti</h1>");
        writer.println("<table border='1' cellpadding='5'><tr><th>ID</th><th>Nume</th><th>Nationalitate</th></tr>");
        if (artists != null) {
            for (ArtistDTO a : artists) {
                writer.println("<tr><td>" + a.getId() + "</td><td>" + a.getName() + "</td><td>" + a.getNationality() + "</td></tr>");
            }
        }
        writer.println("</table></body></html>");
    }

    // --- PARTEA DE AUTENTIFICARE ȘI ROLURI ---

    // 1. Afișează pagina de login
    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    // 2. Procesează datele introduse
    @org.springframework.web.bind.annotation.PostMapping("/login")
    public String processLogin(@org.springframework.web.bind.annotation.RequestParam String username,
                               @org.springframework.web.bind.annotation.RequestParam String password,
                               jakarta.servlet.http.HttpSession session,
                               Model model) {

        // Simulam verificarea rolurilor pe baza numelui de utilizator pentru testare ușoară
        String role = null;

        if (username.equals("admin") && password.equals("123")) role = "Administrator";
        else if (username.equals("manager") && password.equals("123")) role = "Manager";
        else if (username.equals("angajat") && password.equals("123")) role = "Angajat";
        else if (username.equals("vizitator") && password.equals("123")) role = "Vizitator";

        if (role != null) {
            // Dacă logarea e corectă, salvăm datele în sesiune
            session.setAttribute("loggedUser", username);
            session.setAttribute("userRole", role);
            return "redirect:/"; // Îl trimitem pe pagina principală
        } else {
            model.addAttribute("error", "User sau parolă incorecte!");
            return "login";
        }
    }

    // Ruta pentru ȘTERGERE artist (Doar Angajat și Admin)
    @GetMapping("/artists/delete/{id}")
    public String deleteArtist(@org.springframework.web.bind.annotation.PathVariable Integer id,
                               jakarta.servlet.http.HttpSession session) {

        String role = (String) session.getAttribute("userRole");

        // Verificăm dacă are dreptul să șteargă
        if ("Angajat".equals(role) || "Administrator".equals(role)) {
            try {
                restTemplate.delete(GATEWAY_URL + "/" + id);
            } catch (Exception e) {
                System.out.println("Eroare la ștergere: " + e.getMessage());
            }
        }

        // După ștergere, îl întoarcem pe pagina cu lista actualizată
        return "redirect:/artists";
    }

    // --- PARTEA DE ADĂUGARE ȘI EDITARE (CRUD) ---

    // 1. Afișează formularul gol pentru un Artist NOU
    @GetMapping("/artists/new")
    public String showCreateForm(Model model, jakarta.servlet.http.HttpSession session) {
        String role = (String) session.getAttribute("userRole");
        if (!"Angajat".equals(role) && !"Administrator".equals(role)) return "redirect:/"; // Securitate

        model.addAttribute("artist", new ArtistDTO()); // Trimitem un obiect gol către formular
        return "artist-form"; // Va căuta fișierul artist-form.html
    }

    // 2. Afișează formularul completat cu datele unui Artist EXISTENT (Editare)
    @GetMapping("/artists/edit/{id}")
    public String showEditForm(@org.springframework.web.bind.annotation.PathVariable Integer id,
                               Model model,
                               jakarta.servlet.http.HttpSession session) {
        String role = (String) session.getAttribute("userRole");
        if (!"Angajat".equals(role) && !"Administrator".equals(role)) return "redirect:/";

        // Luăm lista de artiști de la Gateway și îl găsim pe cel pe care vrem să îl edităm
        ArtistDTO[] artists = restTemplate.getForObject(GATEWAY_URL, ArtistDTO[].class);
        ArtistDTO artistToEdit = new ArtistDTO();
        if (artists != null) {
            for (ArtistDTO a : artists) {
                if (a.getId().equals(id)) {
                    artistToEdit = a;
                    break;
                }
            }
        }

        model.addAttribute("artist", artistToEdit);
        return "artist-form";
    }

    // --- VÂNZAREA UNUI TABLOU ---
    @GetMapping("/paintings/sell/{id}")
    public String sellPainting(@org.springframework.web.bind.annotation.PathVariable Integer id,
                               jakarta.servlet.http.HttpSession session) {

        String role = (String) session.getAttribute("userRole");

        // Verificăm securitatea: Doar Angajatul și Administratorul pot vinde tablouri
        if ("Angajat".equals(role) || "Administrator".equals(role)) {
            try {
                String PAINTING_GATEWAY_URL = "http://localhost:9000/api/Painting";
                // Apelăm metoda DELETE pentru a scoate tabloul din stoc
                restTemplate.delete(PAINTING_GATEWAY_URL + "/" + id);
            } catch (Exception e) {
                System.out.println("Eroare la vânzarea tabloului: " + e.getMessage());
            }
        }

        // Ne întoarcem la lista de tablouri actualizată
        return "redirect:/paintings";
    }

    // 3. Salvează datele trimise din formular (Atât pentru Adăugare, cât și pentru Editare)
    @org.springframework.web.bind.annotation.PostMapping("/artists/save")
    public String saveArtist(@org.springframework.web.bind.annotation.ModelAttribute ArtistDTO artist,
                             jakarta.servlet.http.HttpSession session) {
        String role = (String) session.getAttribute("userRole");
        if (!"Angajat".equals(role) && !"Administrator".equals(role)) return "redirect:/";

        try {
            if (artist.getId() == null || artist.getId() == 0) {
                // Dacă nu are ID, înseamnă că e NOU -> folosim POST
                restTemplate.postForObject(GATEWAY_URL, artist, Void.class);
            } else {
                // Dacă are ID, înseamnă că îl EDITĂM -> folosim PUT
                restTemplate.put(GATEWAY_URL, artist);
            }
        } catch (Exception e) {
            System.out.println("Eroare la salvare artist: " + e.getMessage());
        }

        return "redirect:/artists"; // Ne întoarcem la tabel după salvare
    }

    // 3. Deconectare (Logout)
    @GetMapping("/logout")
    public String logout(jakarta.servlet.http.HttpSession session) {
        session.invalidate(); // Ștergem sesiunea
        return "redirect:/";
    }
    @GetMapping("/paintings")
    public String paintingsPage(Model model) {
        String PAINTING_GATEWAY_URL = "http://localhost:9000/api/Painting";
        try {
            PaintingDTO[] paintings = restTemplate.getForObject(PAINTING_GATEWAY_URL, PaintingDTO[].class);
            model.addAttribute("paintingsList", paintings);
        } catch (Exception e) {
            model.addAttribute("paintingsList", new PaintingDTO[0]);
        }
        return "paintings";
    }

    // Ruta pentru Dashboard-ul Managerului (Grafice)
    @GetMapping("/manager/dashboard")
    public String managerDashboard(Model model) {
        // Trimitem direct Liste din Java, nu texte simple
        model.addAttribute("artistNames", List.of("Grigorescu", "Tonitza", "Luchian", "Aman"));
        model.addAttribute("paintingCounts", List.of(15, 8, 12, 5));

        model.addAttribute("userRoles", List.of("Administratori", "Manageri", "Angajați", "Vizitatori"));
        model.addAttribute("roleCounts", List.of(1, 3, 10, 45));

        model.addAttribute("months", List.of("Ian", "Feb", "Mar", "Apr", "Mai"));
        model.addAttribute("salesData", List.of(10000, 15000, 8000, 22000, 30000));

        return "dashboard";
    }

    // ==========================================
    // --- PANOU ADMINISTRATOR (UTILIZATORI) ---
    // ==========================================
    private final String USER_GATEWAY_URL = "http://localhost:9000/api/User";

    @GetMapping("/users")
    public String usersPage(Model model, jakarta.servlet.http.HttpSession session) {
        if (!"Administrator".equals(session.getAttribute("userRole"))) return "redirect:/";

        try {
            UserDTO[] users = restTemplate.getForObject(USER_GATEWAY_URL, UserDTO[].class);
            model.addAttribute("usersList", users);
        } catch (Exception e) {
            model.addAttribute("usersList", new UserDTO[0]);
        }
        return "users";
    }

    @GetMapping("/users/export/csv")
    public void exportUsersCSV(jakarta.servlet.http.HttpServletResponse response, jakarta.servlet.http.HttpSession session) throws Exception {
        if (!"Administrator".equals(session.getAttribute("userRole"))) return;

        response.setContentType("text/csv; charset=UTF-8");
        response.setHeader("Content-Disposition", "attachment; filename=\"utilizatori.csv\"");
        UserDTO[] users = restTemplate.getForObject(USER_GATEWAY_URL, UserDTO[].class);

        java.io.PrintWriter writer = response.getWriter();
        writer.println("ID,Username,Rol,Email,Telefon");
        if (users != null) {
            for (UserDTO u : users) {
                writer.println(u.getId() + "," + u.getUsername() + "," + u.getRole() + "," + u.getEmail() + "," + u.getPhoneNumber());
            }
        }
    }

    @GetMapping("/users/new")
    public String showCreateUserForm(Model model, jakarta.servlet.http.HttpSession session) {
        if (!"Administrator".equals(session.getAttribute("userRole"))) return "redirect:/";
        model.addAttribute("user", new UserDTO());
        return "user-form";
    }

    @GetMapping("/users/edit/{id}")
    public String showEditUserForm(@org.springframework.web.bind.annotation.PathVariable Integer id, Model model, jakarta.servlet.http.HttpSession session) {
        if (!"Administrator".equals(session.getAttribute("userRole"))) return "redirect:/";

        UserDTO[] users = restTemplate.getForObject(USER_GATEWAY_URL, UserDTO[].class);
        UserDTO userToEdit = new UserDTO();
        if (users != null) {
            for (UserDTO u : users) {
                if (u.getId().equals(id)) { userToEdit = u; break; }
            }
        }
        model.addAttribute("user", userToEdit);
        return "user-form";
    }

    @org.springframework.web.bind.annotation.PostMapping("/users/save")
    public String saveUser(@org.springframework.web.bind.annotation.ModelAttribute UserDTO userDTO, jakarta.servlet.http.HttpSession session) {
        if (!"Administrator".equals(session.getAttribute("userRole"))) return "redirect:/";

        try {
            if (userDTO.getId() == null || userDTO.getId() == 0) {
                restTemplate.postForObject(USER_GATEWAY_URL, userDTO, Void.class);
            } else {
                // Modificarea unui utilizator va declanșa automat NotificationService din backend!
                restTemplate.put(USER_GATEWAY_URL, userDTO);
            }
        } catch (Exception e) {
            System.out.println("Eroare la salvare user: " + e.getMessage());
        }
        return "redirect:/users";
    }

    @GetMapping("/users/delete/{id}")
    public String deleteUser(@org.springframework.web.bind.annotation.PathVariable Integer id, jakarta.servlet.http.HttpSession session) {
        if (!"Administrator".equals(session.getAttribute("userRole"))) return "redirect:/";
        try {
            restTemplate.delete(USER_GATEWAY_URL + "/" + id);
        } catch (Exception e) {}
        return "redirect:/users";
    }

}