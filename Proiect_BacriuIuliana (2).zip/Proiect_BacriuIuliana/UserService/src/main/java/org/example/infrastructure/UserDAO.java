package org.example.infrastructure;

import org.example.domain.User;
import org.example.domain.daocontracts.IUserDAO;
import org.example.infrastructure.tabelentities.UserEntity;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
@Transactional
public class UserDAO implements IUserDAO {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<User> getAllUsers() {
        return entityManager.createQuery("SELECT u FROM UserEntity u", UserEntity.class)
                .getResultList().stream()
                .map(UserEntity::toUser)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<User> getUserById(Integer id) {
        UserEntity entity = entityManager.find(UserEntity.class, id);
        return Optional.ofNullable(entity).map(UserEntity::toUser);
    }

    @Override
    public boolean insertUser(User user) {
        try {
            UserEntity entity = new UserEntity(user);
            entityManager.persist(entity);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public boolean updateUser(User user) {
        try {
            UserEntity entity = new UserEntity(user);
            entityManager.merge(entity);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public boolean deleteUser(Integer id) {
        try {
            UserEntity entity = entityManager.find(UserEntity.class, id);
            if (entity != null) {
                entityManager.remove(entity);
                return true;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }
}