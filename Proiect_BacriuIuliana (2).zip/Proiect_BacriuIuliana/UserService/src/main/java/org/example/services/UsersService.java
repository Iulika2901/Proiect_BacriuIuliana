package org.example.services;

import org.example.domain.User;
import org.example.domain.daocontracts.IUserDAO;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class UsersService {

    private final IUserDAO userDAO;
    private final RestTemplate restTemplate;

    public UsersService(IUserDAO userDAO) {
        this.userDAO = userDAO;
        this.restTemplate = new RestTemplate();
    }

    public List<User> getUsers() {
        return userDAO.getAllUsers();
    }

    public User getUser(Integer id) {
        return userDAO.getUserById(id).orElse(null);
    }

    public boolean insertUser(User user) {
        return userDAO.insertUser(user);
    }

    public boolean deleteUser(Integer id) {
        return userDAO.deleteUser(id);
    }

    public boolean updateAuthInfo(User updatedUser) {
        boolean success = userDAO.updateUser(updatedUser);

        // Trimite notificarea dacă modificarea în baza de date a avut succes
        if (success) {
            try {
                // Presupunând că NotificationService va rula pe portul 8084
                String notificationUrl = "http://localhost:8084/api/Notification/send?email="
                        + updatedUser.getEmail() + "&phone=" + updatedUser.getPhoneNumber();
                restTemplate.postForObject(notificationUrl, null, String.class);
            } catch (Exception e) {
                System.out.println("Nu s-a putut trimite notificarea (NotificationService este oprit): " + e.getMessage());
            }
        }
        return success;
    }
}