package org.example.domain.daocontracts;

import org.example.domain.User;
import java.util.List;
import java.util.Optional;

public interface IUserDAO {
    List<User> getAllUsers();
    Optional<User> getUserById(Integer id);
    boolean insertUser(User user);
    boolean updateUser(User user);
    boolean deleteUser(Integer id);
}