package org.example.infrastructure.tabelentities;

import org.example.domain.Gallery;
import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "galleries")
public class GalleryEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String name;

    private String location;

    @ElementCollection
    @CollectionTable(name = "gallery_paintings", joinColumns = @JoinColumn(name = "gallery_id"))
    @Column(name = "painting_id")
    private List<Integer> paintingIds = new ArrayList<>();

    public GalleryEntity() {}

    public GalleryEntity(Gallery gallery) {
        this.id = gallery.getId();
        this.name = gallery.getName();
        this.location = gallery.getLocation();
        this.paintingIds = gallery.getPaintingIds();
    }

    public Gallery toGallery() {
        return new Gallery(this.id, this.name, this.location, this.paintingIds);
    }

    // Getteri și Setteri
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public List<Integer> getPaintingIds() { return paintingIds; }
    public void setPaintingIds(List<Integer> paintingIds) { this.paintingIds = paintingIds; }
}