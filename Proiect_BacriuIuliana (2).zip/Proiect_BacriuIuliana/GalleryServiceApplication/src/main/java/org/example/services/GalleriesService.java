package org.example.services;

import org.example.domain.Gallery;
import org.example.domain.daocontracts.IGalleryDAO;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GalleriesService {

    private final IGalleryDAO galleryDAO;

    public GalleriesService(IGalleryDAO galleryDAO) {
        this.galleryDAO = galleryDAO;
    }

    public List<Gallery> getGalleries() {
        return galleryDAO.getAllGalleries();
    }

    public Gallery getGallery(Integer id) {
        return galleryDAO.getGalleryById(id).orElse(null);
    }

    public boolean insertGallery(Gallery gallery) {
        return galleryDAO.insertGallery(gallery);
    }

    public boolean updateGallery(Gallery gallery) {
        return galleryDAO.updateGallery(gallery);
    }

    public boolean deleteGallery(Integer id) {
        return galleryDAO.deleteGallery(id);
    }
}