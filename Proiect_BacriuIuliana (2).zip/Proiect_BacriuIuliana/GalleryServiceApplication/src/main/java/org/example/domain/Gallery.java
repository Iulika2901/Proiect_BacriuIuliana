package org.example.domain;

import java.util.List;

public class Gallery {
    private Integer id;
    private String name;
    private String location;
    private List<Integer> paintingIds;

    public Gallery() {}

    public Gallery(Integer id, String name, String location, List<Integer> paintingIds) {
        this.id = id;
        this.name = name;
        this.location = location;
        this.paintingIds = paintingIds;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public List<Integer> getPaintingIds() { return paintingIds; }
    public void setPaintingIds(List<Integer> paintingIds) { this.paintingIds = paintingIds; }
}