package org.example.controllers;

import org.example.domain.Gallery;
import org.example.services.GalleriesService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/Gallery")
public class GalleryController {

    private final GalleriesService galleriesService;

    public GalleryController(GalleriesService galleriesService) {
        this.galleriesService = galleriesService;
    }

    @GetMapping
    public ResponseEntity<List<Gallery>> getGalleries() {
        return ResponseEntity.ok(galleriesService.getGalleries());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Gallery> getGalleryById(@PathVariable Integer id) {
        Gallery gallery = galleriesService.getGallery(id);
        if (gallery != null) {
            return ResponseEntity.ok(gallery);
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<Void> create(@RequestBody Gallery gallery) {
        if (galleriesService.insertGallery(gallery)) {
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.badRequest().build();
    }

    @PutMapping
    public ResponseEntity<Void> update(@RequestBody Gallery gallery) {
        if (galleriesService.updateGallery(gallery)) {
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.badRequest().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) {
        if (galleriesService.deleteGallery(id)) {
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.badRequest().build();
    }
}