package org.example.infrastructure;

import org.example.domain.Gallery;
import org.example.domain.daocontracts.IGalleryDAO;
import org.example.infrastructure.tabelentities.GalleryEntity;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
@Transactional
public class GalleryDAO implements IGalleryDAO {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<Gallery> getAllGalleries() {
        return entityManager.createQuery("SELECT g FROM GalleryEntity g", GalleryEntity.class)
                .getResultList().stream()
                .map(GalleryEntity::toGallery)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<Gallery> getGalleryById(Integer id) {
        GalleryEntity entity = entityManager.find(GalleryEntity.class, id);
        return Optional.ofNullable(entity).map(GalleryEntity::toGallery);
    }

    @Override
    public boolean insertGallery(Gallery gallery) {
        try {
            GalleryEntity entity = new GalleryEntity(gallery);
            entityManager.persist(entity);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public boolean updateGallery(Gallery gallery) {
        try {
            GalleryEntity entity = new GalleryEntity(gallery);
            entityManager.merge(entity);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public boolean deleteGallery(Integer id) {
        try {
            GalleryEntity entity = entityManager.find(GalleryEntity.class, id);
            if (entity != null) {
                entityManager.remove(entity);
                return true;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }
}