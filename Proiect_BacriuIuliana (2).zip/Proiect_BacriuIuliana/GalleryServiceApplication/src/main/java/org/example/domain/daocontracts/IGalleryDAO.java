package org.example.domain.daocontracts;

import org.example.domain.Gallery;
import java.util.List;
import java.util.Optional;

public interface IGalleryDAO {
    List<Gallery> getAllGalleries();
    Optional<Gallery> getGalleryById(Integer id);
    boolean insertGallery(Gallery gallery);
    boolean updateGallery(Gallery gallery);
    boolean deleteGallery(Integer id);
}