package org.example.controllers;

import org.example.Services.NotificationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/Notification")
public class NotificationController {

    private final NotificationService notificationService;

    public NotificationController(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @PostMapping("/send")
    public ResponseEntity<Void> sendAuthUpdateNotification(@RequestParam String email, @RequestParam String phone) {
        // Apelăm serviciul pentru a trimite alertele
        notificationService.sendNotifications(email, phone);

        // Răspundem cu 200 OK pentru a confirma că notificările au fost procesate
        return ResponseEntity.ok().build();
    }
}