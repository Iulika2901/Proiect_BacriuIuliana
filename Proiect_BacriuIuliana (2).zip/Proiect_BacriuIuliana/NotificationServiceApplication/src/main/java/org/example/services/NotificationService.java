package org.example.Services;

import org.springframework.stereotype.Service;

@Service
public class NotificationService {

    public void sendNotifications(String email, String phoneNumber) {
        // Aici se simulează integrarea cu API-uri externe (ex: SendGrid, Twilio, WhatsApp Business API)

        System.out.println("===============================================================");
        System.out.println("ALERTA DE SECURITATE - MODIFICARE DATE AUTENTIFICARE");
        System.out.println("===============================================================");

        if (email != null && !email.isEmpty()) {
            System.out.println(">>> TRIMITERE EMAIL către [" + email + "]: Datele tale de autentificare au fost modificate de catre administrator.");
        }

        if (phoneNumber != null && !phoneNumber.isEmpty()) {
            System.out.println(">>> TRIMITERE SMS către [" + phoneNumber + "]: Datele tale de autentificare au fost modificate de catre administrator.");
            System.out.println(">>> TRIMITERE WhatsApp către [" + phoneNumber + "]: Datele tale de autentificare au fost modificate de catre administrator.");
        }

        System.out.println("===============================================================\n");
    }
}