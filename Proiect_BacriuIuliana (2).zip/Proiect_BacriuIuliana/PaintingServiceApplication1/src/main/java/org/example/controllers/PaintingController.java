package org.example.controllers;

import org.example.domain.Painting;
import org.example.services.PaintingsService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/Painting")
public class PaintingController {

    private final PaintingsService paintingsService;

    public PaintingController(PaintingsService paintingsService) {
        this.paintingsService = paintingsService;
    }

    @GetMapping
    public ResponseEntity<List<Painting>> getPaintings() {
        return ResponseEntity.ok(paintingsService.getPaintings());
    }

    @GetMapping("/artist/{artistId}")
    public ResponseEntity<List<Painting>> getPaintingsByArtist(@PathVariable Integer artistId) {
        return ResponseEntity.ok(paintingsService.getPaintingsByArtist(artistId));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Painting> getPaintingById(@PathVariable Integer id) {
        Painting painting = paintingsService.getPainting(id);
        if (painting != null) {
            return ResponseEntity.ok(painting);
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<Void> create(@RequestBody Painting painting) {
        if (paintingsService.insertPainting(painting)) {
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.badRequest().build();
    }

    @PutMapping
    public ResponseEntity<Void> update(@RequestBody Painting painting) {
        if (paintingsService.updatePainting(painting)) {
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.badRequest().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) {
        if (paintingsService.deletePainting(id)) {
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.badRequest().build();
    }
}