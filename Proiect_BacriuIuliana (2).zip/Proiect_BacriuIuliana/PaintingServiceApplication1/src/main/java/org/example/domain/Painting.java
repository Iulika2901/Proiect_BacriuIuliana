package org.example.domain;

public class Painting {
    private Integer id;
    private String title;
    private Integer artistId;
    private String type;
    private Double price;
    private String imagePath1;
    private String imagePath2;
    private String imagePath3;

    public Painting() {}

    public Painting(Integer id, String title, Integer artistId, String type, Double price,
                    String imagePath1, String imagePath2, String imagePath3) {
        this.id = id;
        this.title = title;
        this.artistId = artistId;
        this.type = type;
        this.price = price;
        this.imagePath1 = imagePath1;
        this.imagePath2 = imagePath2;
        this.imagePath3 = imagePath3;
    }

    // Getteri și Setteri
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public Integer getArtistId() { return artistId; }
    public void setArtistId(Integer artistId) { this.artistId = artistId; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public Double getPrice() { return price; }
    public void setPrice(Double price) { this.price = price; }

    public String getImagePath1() { return imagePath1; }
    public void setImagePath1(String imagePath1) { this.imagePath1 = imagePath1; }

    public String getImagePath2() { return imagePath2; }
    public void setImagePath2(String imagePath2) { this.imagePath2 = imagePath2; }

    public String getImagePath3() { return imagePath3; }
    public void setImagePath3(String imagePath3) { this.imagePath3 = imagePath3; }
}