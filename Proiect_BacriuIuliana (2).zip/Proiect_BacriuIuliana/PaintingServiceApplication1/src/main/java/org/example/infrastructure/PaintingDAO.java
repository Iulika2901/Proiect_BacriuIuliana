package org.example.infrastructure;

import org.example.domain.Painting;
import org.example.domain.daocontracts.IPaintingDAO;
import org.example.infrastructure.tabelentities.PaintingEntity;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
@Transactional
public class PaintingDAO implements IPaintingDAO {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<Painting> getAllPaintings() {
        return entityManager.createQuery("SELECT p FROM PaintingEntity p", PaintingEntity.class)
                .getResultList().stream()
                .map(PaintingEntity::toPainting)
                .collect(Collectors.toList());
    }

    @Override
    public List<Painting> getPaintingsByArtistId(Integer artistId) {
        return entityManager.createQuery("SELECT p FROM PaintingEntity p WHERE p.artistId = :artistId", PaintingEntity.class)
                .setParameter("artistId", artistId)
                .getResultList().stream()
                .map(PaintingEntity::toPainting)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<Painting> getPaintingById(Integer id) {
        PaintingEntity entity = entityManager.find(PaintingEntity.class, id);
        return Optional.ofNullable(entity).map(PaintingEntity::toPainting);
    }

    @Override
    public boolean insertPainting(Painting painting) {
        try {
            PaintingEntity entity = new PaintingEntity(painting);
            entityManager.persist(entity);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public boolean updatePainting(Painting painting) {
        try {
            PaintingEntity entity = new PaintingEntity(painting);
            entityManager.merge(entity);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public boolean deletePainting(Integer id) {
        try {
            PaintingEntity entity = entityManager.find(PaintingEntity.class, id);
            if (entity != null) {
                entityManager.remove(entity);
                return true;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }
}