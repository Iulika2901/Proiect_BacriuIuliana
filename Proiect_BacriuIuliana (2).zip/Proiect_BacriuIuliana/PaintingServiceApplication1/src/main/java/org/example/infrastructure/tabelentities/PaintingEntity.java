package org.example.infrastructure.tabelentities;

import org.example.domain.Painting;
import jakarta.persistence.*;

@Entity
@Table(name = "paintings")
public class PaintingEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String title;

    @Column(name = "artist_id", nullable = false)
    private Integer artistId;

    private String type;
    private Double price;

    @Column(name = "image_path_1")
    private String imagePath1;

    @Column(name = "image_path_2")
    private String imagePath2;

    @Column(name = "image_path_3")
    private String imagePath3;

    public PaintingEntity() {}

    public PaintingEntity(Painting painting) {
        this.id = painting.getId();
        this.title = painting.getTitle();
        this.artistId = painting.getArtistId();
        this.type = painting.getType();
        this.price = painting.getPrice();
        this.imagePath1 = painting.getImagePath1();
        this.imagePath2 = painting.getImagePath2();
        this.imagePath3 = painting.getImagePath3();
    }

    public Painting toPainting() {
        return new Painting(this.id, this.title, this.artistId, this.type, this.price,
                this.imagePath1, this.imagePath2, this.imagePath3);
    }

    // Getteri și Setteri
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public Integer getArtistId() { return artistId; }
    public void setArtistId(Integer artistId) { this.artistId = artistId; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public Double getPrice() { return price; }
    public void setPrice(Double price) { this.price = price; }

    public String getImagePath1() { return imagePath1; }
    public void setImagePath1(String imagePath1) { this.imagePath1 = imagePath1; }

    public String getImagePath2() { return imagePath2; }
    public void setImagePath2(String imagePath2) { this.imagePath2 = imagePath2; }

    public String getImagePath3() { return imagePath3; }
    public void setImagePath3(String imagePath3) { this.imagePath3 = imagePath3; }
}