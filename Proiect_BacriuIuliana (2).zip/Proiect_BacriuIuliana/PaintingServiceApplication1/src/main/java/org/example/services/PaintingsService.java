package org.example.services;

import org.example.domain.Painting;
import org.example.domain.daocontracts.IPaintingDAO;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PaintingsService {

    private final IPaintingDAO paintingDAO;

    public PaintingsService(IPaintingDAO paintingDAO) {
        this.paintingDAO = paintingDAO;
    }

    public List<Painting> getPaintings() {
        return paintingDAO.getAllPaintings();
    }

    public List<Painting> getPaintingsByArtist(Integer artistId) {
        return paintingDAO.getPaintingsByArtistId(artistId);
    }

    public Painting getPainting(Integer id) {
        return paintingDAO.getPaintingById(id).orElse(null);
    }

    public boolean insertPainting(Painting painting) {
        return paintingDAO.insertPainting(painting);
    }

    public boolean updatePainting(Painting painting) {
        return paintingDAO.updatePainting(painting);
    }

    public boolean deletePainting(Integer id) {
        return paintingDAO.deletePainting(id);
    }
}