package org.example.domain.daocontracts;

import org.example.domain.Painting;
import java.util.List;
import java.util.Optional;

public interface IPaintingDAO {
    List<Painting> getAllPaintings();
    List<Painting> getPaintingsByArtistId(Integer artistId);
    Optional<Painting> getPaintingById(Integer id);
    boolean insertPainting(Painting painting);
    boolean updatePainting(Painting painting);
    boolean deletePainting(Integer id);
}